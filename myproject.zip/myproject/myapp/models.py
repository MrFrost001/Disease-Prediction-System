from django.db import models


class PredictionHistory(models.Model):
    fever       = models.BooleanField(default=False)
    headache    = models.BooleanField(default=False)
    nausea      = models.BooleanField(default=False)
    vomiting    = models.BooleanField(default=False)
    fatigue     = models.BooleanField(default=False)
    joint_pain  = models.BooleanField(default=False)
    skin_rash   = models.BooleanField(default=False)
    cough       = models.BooleanField(default=False)
    weight_loss = models.BooleanField(default=False)
    yellow_eyes = models.BooleanField(default=False)
    result      = models.CharField(max_length=200)
    created_at  = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.result} ({self.created_at.strftime('%d %b %Y')})"